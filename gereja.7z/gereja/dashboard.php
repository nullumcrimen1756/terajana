<?php
require_once 'config.php';
require_once 'functions.php';

session_start();

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Query untuk statistik dashboard
$sql_jurnal = "SELECT j.nama_jurnal, COUNT(t.id_transaksi) as total_transaksi, 
               SUM(t.jumlah) as total_jumlah
               FROM jurnal j
               LEFT JOIN transaksi t ON j.id_jurnal = t.id_jurnal
               GROUP BY j.id_jurnal";
$result_jurnal = $conn->query($sql_jurnal);

$jurnal_stats = [];
if ($result_jurnal->num_rows > 0) {
    while($row = $result_jurnal->fetch_assoc()) {
        $jurnal_stats[] = $row;
    }
}

// Query untuk transaksi terakhir
$sql_last_trans = "SELECT t.*, j.nama_jurnal, k.nama_kategori, s.nama_subkategori
                   FROM transaksi t
                   JOIN jurnal j ON t.id_jurnal = j.id_jurnal
                   LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
                   LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
                   ORDER BY t.tanggal DESC, t.created_at DESC
                   LIMIT 10";
$result_last_trans = $conn->query($sql_last_trans);

$last_transactions = [];
if ($result_last_trans->num_rows > 0) {
    while($row = $result_last_trans->fetch_assoc()) {
        $last_transactions[] = $row;
    }
}

// Query untuk summary bulanan
$current_year = date('Y');
$sql_monthly = "SELECT MONTH(t.tanggal) as bulan, 
                SUM(CASE WHEN t.id_jurnal = 1 THEN t.jumlah ELSE 0 END) as pengeluaran,
                SUM(CASE WHEN t.id_jurnal IN (2,3,4) THEN t.jumlah ELSE 0 END) as penerimaan
                FROM transaksi t
                WHERE YEAR(t.tanggal) = ?
                GROUP BY MONTH(t.tanggal)
                ORDER BY bulan";
$stmt = $conn->prepare($sql_monthly);
$stmt->bind_param("i", $current_year);
$stmt->execute();
$result_monthly = $stmt->get_result();

$monthly_data = array_fill(1, 12, ['pengeluaran' => 0, 'penerimaan' => 0]);
if ($result_monthly->num_rows > 0) {
    while($row = $result_monthly->fetch_assoc()) {
        $monthly_data[$row['bulan']] = [
            'pengeluaran' => $row['pengeluaran'],
            'penerimaan' => $row['penerimaan']
        ];
    }
}

include 'views/dashboard.php';
?>