<?php
function showForm() {
    global $conn, $daftar_jurnal;
    
    // Ambil data jurnal
    $jurnal = [];
    $sql = "SELECT * FROM jurnal ORDER BY nama_jurnal";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $jurnal[] = $row;
        }
    }
    
    // Ambil data kategori untuk jurnal pertama sebagai default
    $kategori = [];
    if (!empty($jurnal)) {
        $first_journal = $jurnal[0]['id_jurnal'];
        $sql = "SELECT * FROM kategori WHERE id_jurnal = ? ORDER BY kode_kategori";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $first_journal);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while($row = $result->fetch_assoc()) {
            $kategori[] = $row;
        }
    }
    
    include 'views/form.php';
}

function getKategoriByJurnal() {
    global $conn;
    
    $id_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : 0;
    
    $kategori = [];
    $sql = "SELECT * FROM kategori WHERE id_jurnal = ? ORDER BY kode_kategori";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_jurnal);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $kategori[] = $row;
    }
    
    header('Content-Type: application/json');
    echo json_encode($kategori);
    exit;
}

function getSubkategori() {
    global $conn;
    
    $id_kategori = isset($_GET['id_kategori']) ? intval($_GET['id_kategori']) : 0;
    
    $subkategori = [];
    $sql = "SELECT * FROM subkategori WHERE id_kategori = ? ORDER BY kode_subkategori";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_kategori);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $subkategori[] = $row;
    }
    
    header('Content-Type: application/json');
    echo json_encode($subkategori);
    exit;
}

function submitForm() {
    global $conn;
    
    // Validasi input
    $errors = [];
    
    if (empty($_POST['tanggal'])) {
        $errors[] = "Tanggal harus diisi";
    }
    
    if (empty($_POST['no_kwitansi'])) {
        $errors[] = "Nomor KW harus diisi";
    }
    
    if (empty($_POST['jumlah']) || !is_numeric($_POST['jumlah']) || $_POST['jumlah'] <= 0) {
        $errors[] = "Jumlah harus angka dan lebih dari 0";
    }
    
    if (empty($_POST['id_jurnal'])) {
        $errors[] = "Silakan pilih jurnal";
    }
    
    if (empty($_POST['id_kategori'])) {
        $errors[] = "Silakan pilih kategori";
    }
    
    if (empty($_POST['id_subkategori'])) {
        $errors[] = "Silakan pilih sub kategori";
    }
    
    if (count($errors) > 0) {
        $_SESSION['errors'] = $errors;
        header("Location: index.php");
        exit;
    }
    
    // Simpan data
    $tanggal = date('Y-m-d', strtotime($_POST['tanggal']));
    $no_kwitansi = $_POST['no_kwitansi'];
    $uraian = $_POST['uraian'];
    $jumlah = $_POST['jumlah'];
    $id_jurnal = $_POST['id_jurnal'];
    $id_subkategori = $_POST['id_subkategori'];
    $setoran = isset($_POST['setoran']) ? $_POST['setoran'] : 0;
    
    $sql = "INSERT INTO transaksi (tanggal, no_kwitansi, uraian, jumlah, id_jurnal, id_subkategori, setoran) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssdidd", $tanggal, $no_kwitansi, $uraian, $jumlah, $id_jurnal, $id_subkategori, $setoran);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Data transaksi berhasil disimpan!";
        
        // Proses laporan
        generateReports();
    } else {
        $_SESSION['errors'] = ["Gagal menyimpan data: " . $conn->error];
    }
    
    header("Location: index.php");
    exit;
}

function generateReports() {
    // Laporan untuk Sheet 2 (Kelompokkan Data Terstruktur)
    generateStructuredReport();
    
    // Laporan untuk Sheet 3 (Salin Total Horizontal)
    generateHorizontalReport();
}

function generateStructuredReport() {
    global $conn;
    
    // Query data transaksi dengan join ke jurnal, kategori, dan subkategori
    $sql = "SELECT t.*, j.nama_jurnal, k.kode_kategori, k.nama_kategori, 
                   s.kode_subkategori, s.nama_subkategori
            FROM transaksi t
            JOIN jurnal j ON t.id_jurnal = j.id_jurnal
            JOIN subkategori s ON t.id_subkategori = s.id_subkategori
            JOIN kategori k ON s.id_kategori = k.id_kategori
            ORDER BY t.tanggal";
    
    $result = $conn->query($sql);
    $transactions = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }
    
    // Kelompokkan data per jurnal dan bulan
    $kelompok = [];
    
    foreach ($transactions as $trx) {
        $jurnal = $trx['nama_jurnal'];
        $bulan = date('F Y', strtotime($trx['tanggal']));
        $kode_sub = $trx['kode_subkategori'] . ' - ' . $trx['nama_subkategori'];
        
        if (!isset($kelompok[$jurnal])) {
            $kelompok[$jurnal] = [];
        }
        
        if (!isset($kelompok[$jurnal][$bulan])) {
            $kelompok[$jurnal][$bulan] = [];
        }
        
        if (!isset($kelompok[$jurnal][$bulan][$kode_sub])) {
            $kelompok[$jurnal][$bulan][$kode_sub] = [
                'total' => 0,
                'transaksi' => []
            ];
        }
        
        $kelompok[$jurnal][$bulan][$kode_sub]['total'] += $trx['jumlah'];
        $kelompok[$jurnal][$bulan][$kode_sub]['transaksi'][] = $trx;
    }
    
    // Simpan ke session untuk ditampilkan
    $_SESSION['structured_report'] = $kelompok;
}

function generateHorizontalReport() {
    global $conn;
    
    // Query data transaksi dengan join ke jurnal, kategori, dan subkategori
    $sql = "SELECT t.*, j.nama_jurnal, k.kode_kategori, k.nama_kategori, 
                   s.kode_subkategori, s.nama_subkategori
            FROM transaksi t
            JOIN jurnal j ON t.id_jurnal = j.id_jurnal
            LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
            LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
            ORDER BY t.tanggal";
    
    $result = $conn->query($sql);
    $transactions = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }
    
    // Kelompokkan data per jurnal
    $report = [];
    
    foreach ($transactions as $trx) {
        $jurnal = $trx['nama_jurnal'];
        $bulan = date('F Y', strtotime($trx['tanggal']));
        
        if (!isset($report[$jurnal])) {
            $report[$jurnal] = [
                'bulan' => [],
                'kategori' => [],
                'subkategori' => [],
                'total_kategori' => [],
                'total_kelompok' => [],
                'total_keseluruhan' => []
            ];
        }
        
        // Kumpulkan semua bulan unik per jurnal
        if (!in_array($bulan, $report[$jurnal]['bulan'])) {
            $report[$jurnal]['bulan'][] = $bulan;
        }
    }
    
    // Urutkan bulan untuk setiap jurnal
    foreach ($report as $jurnal => $data) {
        usort($report[$jurnal]['bulan'], function($a, $b) {
            return strtotime($a) - strtotime($b);
        });
    }
    
    // Hitung total per subkategori per bulan per jurnal
    foreach ($transactions as $trx) {
        $jurnal = $trx['nama_jurnal'];
        $bulan = date('F Y', strtotime($trx['tanggal']));
        $kode_kategori = $trx['kode_kategori'] ?? '';
        $kode_subkategori = $trx['kode_subkategori'] ?? '';
        
        if ($kode_kategori && $kode_subkategori) {
            $key = $kode_kategori . '|' . $kode_subkategori;
            
            if (!isset($report[$jurnal]['subkategori'][$key])) {
                $report[$jurnal]['subkategori'][$key] = [
                    'kode_kategori' => $kode_kategori,
                    'nama_kategori' => $trx['nama_kategori'],
                    'kode_subkategori' => $kode_subkategori,
                    'nama_subkategori' => $trx['nama_subkategori'],
                    'bulan' => []
                ];
            }
            
            if (!isset($report[$jurnal]['subkategori'][$key]['bulan'][$bulan])) {
                $report[$jurnal]['subkategori'][$key]['bulan'][$bulan] = 0;
            }
            
            $report[$jurnal]['subkategori'][$key]['bulan'][$bulan] += $trx['jumlah'];
            
            // Hitung total per kategori
            if (!isset($report[$jurnal]['total_kategori'][$kode_kategori]['bulan'][$bulan])) {
                $report[$jurnal]['total_kategori'][$kode_kategori]['bulan'][$bulan] = 0;
            }
            $report[$jurnal]['total_kategori'][$kode_kategori]['bulan'][$bulan] += $trx['jumlah'];
            
            // Hitung total per kelompok (3 digit pertama)
            $kelompok = substr($kode_kategori, 0, 3);
            if (!isset($report[$jurnal]['total_kelompok'][$kelompok]['bulan'][$bulan])) {
                $report[$jurnal]['total_kelompok'][$kelompok]['bulan'][$bulan] = 0;
            }
            $report[$jurnal]['total_kelompok'][$kelompok]['bulan'][$bulan] += $trx['jumlah'];
            
            // Hitung total keseluruhan per bulan
            if (!isset($report[$jurnal]['total_keseluruhan'][$bulan])) {
                $report[$jurnal]['total_keseluruhan'][$bulan] = 0;
            }
            $report[$jurnal]['total_keseluruhan'][$bulan] += $trx['jumlah'];
        }
    }
    
    // Simpan ke session untuk ditampilkan
    $_SESSION['horizontal_report'] = $report;
}

function showReport() {
    // Tampilkan laporan yang sudah di-generate
    if (isset($_GET['type']) && $_GET['type'] == 'structured') {
        include 'views/structured_report.php';
    } else {
        include 'views/horizontal_report.php';
    }
}