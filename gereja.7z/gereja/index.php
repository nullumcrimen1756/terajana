<?php
require_once 'config.php';
require_once 'functions.php';

session_start();

$action = isset($_GET['action']) ? $_GET['action'] : 'form';

switch ($action) {
    case 'form':
        showForm();
        break;
    case 'submit':
        submitForm();
        break;
    case 'report':
        showReport();
        break;
    case 'get_kategori':
        getKategoriByJurnal();
        break;
    case 'get_subkategori':
        getSubkategori();
        break;
    default:
        showForm();
}