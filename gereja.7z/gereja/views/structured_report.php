
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Terstruktur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #2c3e50;
        }
        .nav {
            margin-bottom: 20px;
            text-align: center;
        }
        .nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #3498db;
        }
        .month-section {
            margin-bottom: 30px;
            break-inside: avoid;
        }
        .month-header {
            font-weight: bold;
            font-size: 18px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        .subcategory-section {
            margin-left: 20px;
            margin-bottom: 15px;
        }
        .subcategory-header {
            font-weight: bold;
            margin-bottom: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .total-row {
            font-weight: bold;
            background-color: #e6f7ff;
        }
        @media print {
            .nav {
                display: none;
            }
            .month-section {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <h1>Laporan Pengeluaran Terstruktur</h1>
    
    <div class="nav">
        <a href="index.php">Form Input</a>
        <a href="index.php?action=report&type=structured">Laporan Terstruktur</a>
        <a href="index.php?action=report">Laporan Horizontal</a>
    </div>
    
    <?php if (isset($_SESSION['structured_report']) && !empty($_SESSION['structured_report'])): ?>
        <?php foreach ($_SESSION['structured_report'] as $bulan => $subcategories): ?>
            <div class="month-section">
                <div class="month-header"><?php echo $bulan; ?></div>
                
                <?php foreach ($subcategories as $subcategory => $data): ?>
                    <div class="subcategory-section">
                        <div class="subcategory-header">Subkategori: <?php echo $subcategory; ?></div>
                        
                        <table>
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Kwitansi</th>
                                    <th>Uraian</th>
                                    <th>Kas</th>
                                    <th>Kode Subkategori</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['transaksi'] as $trx): ?>
                                    <tr>
                                        <td><?php echo date('d-m-Y', strtotime($trx['tanggal'])); ?></td>
                                        <td><?php echo $trx['no_kwitansi']; ?></td>
                                        <td><?php echo $trx['uraian']; ?></td>
                                        <td><?php echo number_format($trx['jumlah'], 2); ?></td>
                                        <td><?php echo $trx['kode_subkategori']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr class="total-row">
                                    <td colspan="3">Total Kas <?php echo $subcategory; ?></td>
                                    <td><?php echo number_format($data['total'], 2); ?></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Tidak ada data laporan terstruktur. Silakan input data terlebih dahulu.</p>
    <?php endif; ?>
</body>
</html>