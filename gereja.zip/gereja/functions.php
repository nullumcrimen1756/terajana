<?php
function showForm() {
    global $conn, $daftar_jurnal;
    
    // Ambil data jurnal
    $jurnal = [];
    $sql = "SELECT * FROM jurnal ORDER BY nama_jurnal";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $jurnal[] = $row;
        }
    }
    
    // Ambil data kategori untuk jurnal pertama sebagai default
    $kategori = [];
    if (!empty($jurnal)) {
        $first_journal = $jurnal[0]['id_jurnal'];
        $sql = "SELECT * FROM kategori WHERE id_jurnal = ? ORDER BY kode_kategori";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $first_journal);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while($row = $result->fetch_assoc()) {
            $kategori[] = $row;
        }
    }
    
    include 'views/form.php';
}

function getKategoriByJurnal() {
    global $conn;
    
    $id_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : 0;
    
    $kategori = [];
    $sql = "SELECT * FROM kategori WHERE id_jurnal = ? ORDER BY kode_kategori";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_jurnal);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $kategori[] = $row;
    }
    
    header('Content-Type: application/json');
    echo json_encode($kategori);
    exit;
}

function getSubkategori() {
    global $conn;
    
    $id_kategori = isset($_GET['id_kategori']) ? intval($_GET['id_kategori']) : 0;
    
    // Debug log
    error_log("getSubkategori called with id_kategori: " . $id_kategori);
    
    $subkategori = [];
    $sql = "SELECT * FROM subkategori WHERE id_kategori = ? ORDER BY kode_subkategori";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_kategori);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $subkategori[] = $row;
    }
    
    // Debug log
    error_log("Subkategori found: " . count($subkategori));
    error_log("Data: " . json_encode($subkategori));
    
    header('Content-Type: application/json');
    echo json_encode($subkategori);
    exit;
}

function submitForm() {
    global $conn;
    
    // Validasi input
    $errors = [];
    
    if (empty($_POST['tanggal'])) {
        $errors[] = "Tanggal harus diisi";
    }
    
    if (empty($_POST['no_kwitansi'])) {
        $errors[] = "Nomor KW harus diisi";
    }
    
    if (empty($_POST['jumlah']) || !is_numeric($_POST['jumlah']) || $_POST['jumlah'] <= 0) {
        $errors[] = "Jumlah harus angka dan lebih dari 0";
    }
    
    if (empty($_POST['id_jurnal'])) {
        $errors[] = "Silakan pilih jurnal";
    }
    
    if (empty($_POST['id_kategori'])) {
        $errors[] = "Silakan pilih kategori";
    }
    
    if (empty($_POST['id_subkategori'])) {
        $errors[] = "Silakan pilih sub kategori";
    }
    
    if (count($errors) > 0) {
        $_SESSION['errors'] = $errors;
        header("Location: index.php");
        exit;
    }
    
    // Simpan data
    $tanggal = date('Y-m-d', strtotime($_POST['tanggal']));
    $no_kwitansi = $_POST['no_kwitansi'];
    $uraian = $_POST['uraian'];
    $jumlah = $_POST['jumlah'];
    $id_jurnal = $_POST['id_jurnal'];
    $id_subkategori = $_POST['id_subkategori'];
    $setoran = isset($_POST['setoran']) ? $_POST['setoran'] : 0;
    
    $sql = "INSERT INTO transaksi (tanggal, no_kwitansi, uraian, jumlah, id_jurnal, id_subkategori, setoran) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssdidd", $tanggal, $no_kwitansi, $uraian, $jumlah, $id_jurnal, $id_subkategori, $setoran);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Data transaksi berhasil disimpan!";
        
        // Proses laporan (Sheet 2 dan Sheet 3)
        generateReports();
    } else {
        $_SESSION['errors'] = ["Gagal menyimpan data: " . $conn->error];
    }
    
    header("Location: index.php");
    exit;
}

// Fungsi untuk menghasilkan laporan Sheet 2 (Terstruktur)
function generateSheet2Report() {
    global $conn;
    
    $sql = "SELECT 
                DATE_FORMAT(t.tanggal, '%M %Y') as bulan,
                CONCAT(k.kode_kategori, ' - ', k.nama_kategori) as kategori,
                CONCAT(s.kode_subkategori, ' - ', s.nama_subkategori) as subkategori,
                t.tanggal,
                t.no_kwitansi,
                t.uraian,
                t.jumlah,
                j.nama_jurnal
            FROM transaksi t
            JOIN jurnal j ON t.id_jurnal = j.id_jurnal
            LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
            LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
            ORDER BY t.tanggal, j.nama_jurnal, k.kode_kategori, s.kode_subkategori";
    
    $result = $conn->query($sql);
    $transactions = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }
    
    // Kelompokkan data berdasarkan jurnal, bulan, dan subkategori
    $structured_data = [];
    
    foreach ($transactions as $trx) {
        $jurnal = $trx['nama_jurnal'];
        $bulan = $trx['bulan'];
        $subkategori = $trx['subkategori'] ?: 'Uang Setoran';
        
        if (!isset($structured_data[$jurnal])) {
            $structured_data[$jurnal] = [];
        }
        
        if (!isset($structured_data[$jurnal][$bulan])) {
            $structured_data[$jurnal][$bulan] = [];
        }
        
        if (!isset($structured_data[$jurnal][$bulan][$subkategori])) {
            $structured_data[$jurnal][$bulan][$subkategori] = [
                'kategori' => $trx['kategori'],
                'transactions' => [],
                'total' => 0
            ];
        }
        
        $structured_data[$jurnal][$bulan][$subkategori]['transactions'][] = [
            'tanggal' => $trx['tanggal'],
            'no_kwitansi' => $trx['no_kwitansi'],
            'uraian' => $trx['uraian'],
            'jumlah' => $trx['jumlah']
        ];
        
        $structured_data[$jurnal][$bulan][$subkategori]['total'] += $trx['jumlah'];
    }
    
    // Simpan ke session untuk ditampilkan
    $_SESSION['sheet2_report'] = $structured_data;
}

// Fungsi untuk menghasilkan laporan Sheet 3 (Horizontal)
function generateSheet3Report() {
    global $conn;
    
    $sql = "SELECT 
                t.*, 
                j.nama_jurnal, 
                k.kode_kategori, 
                k.nama_kategori, 
                s.kode_subkategori, 
                s.nama_subkategori,
                DATE_FORMAT(t.tanggal, '%M %Y') as bulan_format
            FROM transaksi t
            JOIN jurnal j ON t.id_jurnal = j.id_jurnal
            LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
            LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
            ORDER BY t.tanggal";
    
    $result = $conn->query($sql);
    $transactions = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }
    
    // Struktur data untuk laporan horizontal
    $report = [
        'bulan' => [],
        'subkategori' => [],
        'total_kelompok' => [],
        'total_keseluruhan' => []
    ];
    
    // Kumpulkan semua bulan unik
    foreach ($transactions as $trx) {
        $bulan = $trx['bulan_format'];
        if (!in_array($bulan, $report['bulan'])) {
            $report['bulan'][] = $bulan;
        }
    }
    
    // Urutkan bulan secara kronologis
    usort($report['bulan'], function($a, $b) {
        return strtotime($a) - strtotime($b);
    });
    
    // Hitung total per subkategori per bulan
    foreach ($transactions as $trx) {
        $bulan = $trx['bulan_format'];
        $kode_kategori = $trx['kode_kategori'] ?? '';
        $kode_subkategori = $trx['kode_subkategori'] ?? '';
        
        if ($kode_kategori && $kode_subkategori) {
            $key = $kode_kategori . '|' . $kode_subkategori;
            
            if (!isset($report['subkategori'][$key])) {
                $report['subkategori'][$key] = [
                    'kode_kategori' => $kode_kategori,
                    'nama_kategori' => $trx['nama_kategori'],
                    'kode_subkategori' => $kode_subkategori,
                    'nama_subkategori' => $trx['nama_subkategori'],
                    'bulan' => []
                ];
            }
            
            if (!isset($report['subkategori'][$key]['bulan'][$bulan])) {
                $report['subkategori'][$key]['bulan'][$bulan] = 0;
            }
            
            $report['subkategori'][$key]['bulan'][$bulan] += $trx['jumlah'];
            
            // Hitung total per kelompok (3 digit pertama)
            $kelompok = substr($kode_kategori, 0, 3);
            if (!isset($report['total_kelompok'][$kelompok]['bulan'][$bulan])) {
                $report['total_kelompok'][$kelompok]['bulan'][$bulan] = 0;
            }
            $report['total_kelompok'][$kelompok]['bulan'][$bulan] += $trx['jumlah'];
            
            // Hitung total keseluruhan per bulan
            if (!isset($report['total_keseluruhan'][$bulan])) {
                $report['total_keseluruhan'][$bulan] = 0;
            }
            $report['total_keseluruhan'][$bulan] += $trx['jumlah'];
        }
    }
    
    // Simpan ke session untuk ditampilkan
    $_SESSION['sheet3_report'] = $report;
}

// Modifikasi fungsi generateReports untuk memanggil kedua laporan
function generateReports() {
    generateSheet2Report(); // Laporan Sheet 2 (Terstruktur)
    generateSheet3Report(); // Laporan Sheet 3 (Horizontal)
}

function showReport() {
	// Tampilkan laporan berdasarkan type
	if (isset($_GET['type']) && $_GET['type'] == 'structured') {
		generateStructuredReport();
		include 'views/structured_report.php';
	} else {
		generateSheet3Report(); // gunakan fungsi baru
		include 'views/sheet3_report.php'; // gunakan view baru
	}
}

/**
 * Validasi format kode kategori
 * @param string $kode
 * @return bool
 */
function validateKategoriCode($kode) {
    return preg_match('/^[0-9]{3}$/', $kode);
}

/**
 * Validasi format kode subkategori
 * @param string $kode
 * @return bool
 */
function validateSubkategoriCode($kode) {
    // Format: xxx.xx.xx atau xxx.xx.xxx
    return preg_match('/^[0-9]{3}\.[0-9]{2}(\.[0-9]{2,3})?$/', $kode);
}

/**
 * Generate kode subkategori otomatis berdasarkan kategori
 * @param string $kode_kategori
 * @param int $level
 * @return string
 */
function generateSubkategoriCode($kode_kategori, $level = 1) {
    if (!validateKategoriCode($kode_kategori)) {
        return false;
    }
    
    switch ($level) {
        case 1:
            return $kode_kategori . '.01';
        case 2:
            return $kode_kategori . '.01.001';
        default:
            return false;
    }
}

/**
 * Parse kode subkategori untuk mendapatkan informasi level
 * @param string $kode
 * @return array
 */
function parseSubkategoriCode($kode) {
    if (!validateSubkategoriCode($kode)) {
        return false;
    }
    
    $parts = explode('.', $kode);
    return [
        'kategori' => $parts[0],
        'sub_level_1' => $parts[1],
        'sub_level_2' => isset($parts[2]) ? $parts[2] : null,
        'total_levels' => count($parts)
    ];
}