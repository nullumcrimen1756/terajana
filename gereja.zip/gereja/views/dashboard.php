<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Keuangan Gereja</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }
        .header {
            background-color: #2c3e50;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .nav {
            background-color: #34495e;
            padding: 10px 20px;
        }
        .nav a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .nav a:hover {
            background-color: #2c3e50;
        }
        .container {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .card h2 {
            margin-top: 0;
            color: #2c3e50;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px;
            text-align: center;
        }
        .stat-card h3 {
            margin-top: 0;
            color: #7f8c8d;
            font-size: 16px;
        }
        .stat-card .value {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
        }
        .stat-card.pengeluaran .value {
            color: #e74c3c;
        }
        .stat-card.penerimaan .value {
            color: #27ae60;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .chart-container {
            height: 300px;
            margin-top: 20px;
        }
        .logout-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .logout-btn:hover {
            background-color: #c0392b;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="header">
        <h1>Dashboard Keuangan Gereja</h1>
        <form action="logout.php" method="post">
            <button type="submit" class="logout-btn">Logout</button>
        </form>
    </div>
    
    <div class="nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="index.php">Input Transaksi</a>
        <a href="index.php?action=report">Laporan</a>
        <a href="admin_kategori.php">Kelola Kategori</a>
    </div>
    
    <div class="container">
        <div class="stats-container">
            <?php foreach ($jurnal_stats as $stat): ?>
                <div class="stat-card <?php echo strpos(strtolower($stat['nama_jurnal']), 'pengeluaran') !== false ? 'pengeluaran' : 'penerimaan'; ?>">
                    <h3><?php echo htmlspecialchars($stat['nama_jurnal']); ?></h3>
                    <div class="value">Rp <?php echo number_format($stat['total_jumlah'] ?? 0, 2); ?></div>
                    <div><?php echo $stat['total_transaksi'] ?? 0; ?> transaksi</div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="card">
            <h2>Statistik Bulanan Tahun <?php echo date('Y'); ?></h2>
            <div class="chart-container">
                <canvas id="monthlyChart"></canvas>
            </div>
        </div>
        
        <div class="card">
            <h2>10 Transaksi Terakhir</h2>
            <table>
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Jurnal</th>
                        <th>No. Kwitansi</th>
                        <th>Kategori</th>
                        <th>Subkategori</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($last_transactions as $trans): ?>
                        <tr>
                            <td><?php echo date('d/m/Y', strtotime($trans['tanggal'])); ?></td>
                            <td><?php echo htmlspecialchars($trans['nama_jurnal']); ?></td>
                            <td><?php echo htmlspecialchars($trans['no_kwitansi']); ?></td>
                            <td><?php echo htmlspecialchars($trans['nama_kategori'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($trans['nama_subkategori'] ?? '-'); ?></td>
                            <td>Rp <?php echo number_format($trans['jumlah'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Data untuk chart
        const monthlyData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des'],
            datasets: [
                {
                    label: 'Pengeluaran',
                    data: [
                        <?php echo $monthly_data[1]['pengeluaran']; ?>,
                        <?php echo $monthly_data[2]['pengeluaran']; ?>,
                        <?php echo $monthly_data[3]['pengeluaran']; ?>,
                        <?php echo $monthly_data[4]['pengeluaran']; ?>,
                        <?php echo $monthly_data[5]['pengeluaran']; ?>,
                        <?php echo $monthly_data[6]['pengeluaran']; ?>,
                        <?php echo $monthly_data[7]['pengeluaran']; ?>,
                        <?php echo $monthly_data[8]['pengeluaran']; ?>,
                        <?php echo $monthly_data[9]['pengeluaran']; ?>,
                        <?php echo $monthly_data[10]['pengeluaran']; ?>,
                        <?php echo $monthly_data[11]['pengeluaran']; ?>,
                        <?php echo $monthly_data[12]['pengeluaran']; ?>
                    ],
                    backgroundColor: 'rgba(231, 76, 60, 0.5)',
                    borderColor: 'rgba(231, 76, 60, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Penerimaan',
                    data: [
                        <?php echo $monthly_data[1]['penerimaan']; ?>,
                        <?php echo $monthly_data[2]['penerimaan']; ?>,
                        <?php echo $monthly_data[3]['penerimaan']; ?>,
                        <?php echo $monthly_data[4]['penerimaan']; ?>,
                        <?php echo $monthly_data[5]['penerimaan']; ?>,
                        <?php echo $monthly_data[6]['penerimaan']; ?>,
                        <?php echo $monthly_data[7]['penerimaan']; ?>,
                        <?php echo $monthly_data[8]['penerimaan']; ?>,
                        <?php echo $monthly_data[9]['penerimaan']; ?>,
                        <?php echo $monthly_data[10]['penerimaan']; ?>,
                        <?php echo $monthly_data[11]['penerimaan']; ?>,
                        <?php echo $monthly_data[12]['penerimaan']; ?>
                    ],
                    backgroundColor: 'rgba(39, 174, 96, 0.5)',
                    borderColor: 'rgba(39, 174, 96, 1)',
                    borderWidth: 1
                }
            ]
        };

        // Konfigurasi chart
        const config = {
            type: 'bar',
            data: monthlyData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString();
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += 'Rp ' + context.raw.toLocaleString();
                                return label;
                            }
                        }
                    }
                }
            }
        };

        // Buat chart
        window.onload = function() {
            const ctx = document.getElementById('monthlyChart').getContext('2d');
            new Chart(ctx, config);
        };
    </script>
</body>
</html>