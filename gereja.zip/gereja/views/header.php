<?php
// views/header.php
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'Sistem Keuangan Gereja'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            padding-top: 60px;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 20px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        
        .nav {
            background-color: #34495e;
            padding: 10px 20px;
            position: fixed;
            top: 60px;
            left: 0;
            right: 0;
            z-index: 999;
        }
        
        .nav a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        .nav a:hover {
            background-color: var(--primary-color);
        }
        
        .nav a.active {
            background-color: var(--secondary-color);
        }
        
        .logout-btn {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .logout-btn:hover {
            background-color: #c0392b;
        }
        
        .container {
            margin-top: 40px;
        }
        
        /* Tambahan untuk tabel data terstruktur */
        .table-structured {
            width: 100%;
            margin-bottom: 1rem;
            color: #212529;
        }
        
        .table-structured th {
            background-color: #2c3e50;
            color: white;
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }
        
        .table-structured td {
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }
        
        .table-structured tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .table-structured tfoot tr {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .text-end {
            text-align: right !important;
        }
        
        /* Tambahan untuk dashboard */
        .summary-card {
            border-left: 4px solid var(--secondary-color);
        }
        
        .table-structured {
            font-size: 0.9rem;
        }
        
        .table-structured th {
            background-color: var(--primary-color);
            color: white;
            padding: 0.5rem;
            font-size: 0.85rem;
        }
        
        .table-structured td {
            padding: 0.5rem;
            font-size: 0.85rem;
        }
        
        .table-structured tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .table-structured tfoot tr {
            background-color: var(--light-bg);
            font-weight: bold;
        }
        
        .list-group-item {
            border-left: 3px solid var(--secondary-color);
        }
        
        .card-header h6 {
            color: var(--primary-color);
            font-weight: 600;
        }

        /* Tambahan untuk form validation */
        .form-control:invalid {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(231, 76, 60, 0.25);
        }
        
        .form-control:valid {
            border-color: #28a745;
            border-width: 2px;
            box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
        }
        
        .form-text {
            font-size: 0.875rem;
            color: #6c757d;
            line-height: 1.4;
        }
        
        .form-text i {
            color: var(--secondary-color);
        }
        
        .form-text strong {
            color: var(--primary-color);
        }
        
        .form-text .text-muted {
            color: #6c757d !important;
        }
        
        .form-text .text-success {
            color: #28a745 !important;
        }
        
        /* Styling untuk input yang sedang difokuskan */
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        /* Styling untuk placeholder */
        .form-control::placeholder {
            color: #adb5bd;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><i class="bi bi-cash-coin me-2"></i>Sistem Keuangan Gereja</h1>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            <form action="logout.php" method="post">
                <button type="submit" class="logout-btn">
                    <i class="bi bi-box-arrow-right me-1"></i>Logout
                </button>
            </form>
        <?php endif; ?>
    </div>
    
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
    <div class="nav">
        <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="bi bi-speedometer2 me-1"></i>Dashboard
        </a>
        <a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
            <i class="bi bi-journal-plus me-1"></i>Input Transaksi
        </a>
        <a href="index.php?action=report" class="<?php echo isset($_GET['action']) && $_GET['action'] == 'report' ? 'active' : ''; ?>">
            <i class="bi bi-file-earmark-text me-1"></i>Laporan
        </a>
        <a href="admin_kategori.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'admin_kategori.php' ? 'active' : ''; ?>">
            <i class="bi bi-tags me-1"></i>Kelola Kategori
        </a>
        <a href="index.php?action=sheet2_report" class="nav-link <?php echo isset($_GET['action']) && $_GET['action'] == 'sheet2_report' ? 'active' : ''; ?>">
            <i class="bi bi-list-check me-1"></i>Laporan Sheet 2
        </a>
        <a href="index.php?action=sheet3_report" class="nav-link <?php echo isset($_GET['action']) && $_GET['action'] == 'sheet3_report' ? 'active' : ''; ?>">
            <i class="bi bi-table me-1"></i>Laporan Sheet 3
        </a>
    </div>
    <?php endif; ?>
    
    <div class="container">
