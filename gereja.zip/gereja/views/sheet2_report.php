<?php
if (!isset($_SESSION['sheet2_report']) || empty($_SESSION['sheet2_report'])) {
    echo "<div class='alert alert-info'>Tidak ada data laporan. Silakan input data terlebih dahulu.</div>";
    return;
}

$report = $_SESSION['sheet2_report'];
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <i class="bi bi-list-check me-2"></i>Laporan Terstruktur (Sheet 2)
        </h5>
    </div>
    <div class="card-body">
        <?php foreach ($report as $jurnal => $bulan_data): ?>
            <h4 class="text-primary mb-3"><?= htmlspecialchars($jurnal) ?></h4>
            
            <?php foreach ($bulan_data as $bulan => $subkategori_data): ?>
                <div class="mb-4">
                    <h5 class="text-secondary"><?= htmlspecialchars($bulan) ?></h5>
                    
                    <?php foreach ($subkategori_data as $subkategori => $data): ?>
                        <div class="mb-3">
                            <h6 class="text-dark"><?= htmlspecialchars($subkategori) ?></h6>
                            
                            <div class="table-responsive">
                                <table class="table table-bordered table-sm">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Tanggal</th>
                                            <th>No. Kwitansi</th>
                                            <th>Uraian</th>
                                            <th class="text-end">Jumlah</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($data['transactions'] as $trans): ?>
                                            <tr>
                                                <td><?= date('d-m-Y', strtotime($trans['tanggal'])) ?></td>
                                                <td><?= htmlspecialchars($trans['no_kwitansi']) ?></td>
                                                <td><?= htmlspecialchars($trans['uraian']) ?></td>
                                                <td class="text-end">Rp <?= number_format($trans['jumlah'], 0, ',', '.') ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot class="table-info">
                                        <tr>
                                            <th colspan="3" class="text-end">Total</th>
                                            <th class="text-end fw-bold">Rp <?= number_format($data['total'], 0, ',', '.') ?></th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <hr>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </div>
</div>
