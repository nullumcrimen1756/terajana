<?php
if (!isset($_SESSION['sheet3_report']) || empty($_SESSION['sheet3_report'])) {
    echo "<div class='alert alert-info'>Tidak ada data laporan. Silakan input data terlebih dahulu.</div>";
    return;
}

$report = $_SESSION['sheet3_report'];
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <i class="bi bi-table me-2"></i>Laporan Horizontal (Sheet 3)
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Kategori</th>
                        <th>Kode Subkategori</th>
                        <th>Uraian</th>
                        <?php foreach ($report['bulan'] as $bulan): ?>
                            <th class="text-center"><?= htmlspecialchars($bulan) ?></th>
                        <?php endforeach; ?>
                        <th class="text-center">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $current_group = '';
                    $group_totals = array_fill_keys($report['bulan'], 0);
                    $overall_totals = array_fill_keys($report['bulan'], 0);
                    ?>
                    
                    <?php foreach ($report['subkategori'] as $key => $sub): ?>
                        <?php
                        $group = substr($sub['kode_kategori'], 0, 3);
                        
                        // Tampilkan total kelompok jika kelompok berubah
                        if ($group !== $current_group && $current_group !== ''): ?>
                            <tr class="table-warning">
                                <td colspan="2"><strong>Total Kelompok <?= $current_group ?></strong></td>
                                <td></td>
                                <?php 
                                $group_total = 0;
                                foreach ($report['bulan'] as $bulan): 
                                    $amount = $group_totals[$bulan] ?? 0;
                                    $group_total += $amount;
                                ?>
                                    <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($group_total, 0, ',', '.') ?></td>
                            </tr>
                            <?php 
                            // Reset group totals
                            $group_totals = array_fill_keys($report['bulan'], 0);
                        endif;
                        
                        $current_group = $group;
                        ?>
                        
                        <tr>
                            <td><?= htmlspecialchars($sub['kode_kategori'] . ' - ' . $sub['nama_kategori']) ?></td>
                            <td><?= htmlspecialchars($sub['kode_subkategori']) ?></td>
                            <td><?= htmlspecialchars($sub['nama_subkategori']) ?></td>
                            <?php 
                            $sub_total = 0;
                            foreach ($report['bulan'] as $bulan): 
                                $amount = $sub['bulan'][$bulan] ?? 0;
                                $sub_total += $amount;
                                $group_totals[$bulan] += $amount;
                                $overall_totals[$bulan] += $amount;
                            ?>
                                <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                            <?php endforeach; ?>
                            <td class="text-end fw-bold">Rp <?= number_format($sub_total, 0, ',', '.') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    
                    <!-- Total kelompok terakhir -->
                    <?php if ($current_group !== ''): ?>
                        <tr class="table-warning">
                            <td colspan="2"><strong>Total Kelompok <?= $current_group ?></strong></td>
                            <td></td>
                            <?php 
                            $group_total = 0;
                            foreach ($report['bulan'] as $bulan): 
                                $amount = $group_totals[$bulan] ?? 0;
                                $group_total += $amount;
                            ?>
                                <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                            <?php endforeach; ?>
                            <td class="text-end fw-bold">Rp <?= number_format($group_total, 0, ',', '.') ?></td>
                        </tr>
                    <?php endif; ?>
                    
                    <!-- Total keseluruhan -->
                    <tr class="table-primary">
                        <td colspan="2"><strong>TOTAL KESELURUHAN</strong></td>
                        <td></td>
                        <?php 
                        $grand_total = 0;
                        foreach ($report['bulan'] as $bulan): 
                            $amount = $overall_totals[$bulan] ?? 0;
                            $grand_total += $amount;
                        ?>
                            <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                        <?php endforeach; ?>
                        <td class="text-end fw-bold">Rp <?= number_format($grand_total, 0, ',', '.') ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
