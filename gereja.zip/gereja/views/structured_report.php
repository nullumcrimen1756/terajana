
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Terstruktur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            font-size: 12px;
        }
        h1 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 30px;
        }
        .nav {
            margin-bottom: 20px;
            text-align: center;
        }
        .nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #3498db;
        }
        .month-section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        .month-header {
            background-color: #3498db;
            color: white;
            padding: 10px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 15px;
        }
        .subcategory-section {
            margin-bottom: 20px;
            border: 1px solid #ddd;
        }
        .subcategory-header {
            background-color: #ecf0f1;
            padding: 8px;
            font-weight: bold;
            border-bottom: 1px solid #ddd;
        }
        .transaction-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        .transaction-table th,
        .transaction-table td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: left;
            font-size: 11px;
        }
        .transaction-table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .total-row {
            background-color: #d4edda;
            font-weight: bold;
            text-align: right;
        }
        .setoran-section {
            background-color: #d1ecf1;
            border: 2px solid #17a2b8;
        }
        .setoran-header {
            background-color: #17a2b8;
            color: white;
        }
        @media print {
            .nav { display: none; }
            .month-section { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
    <h1>Laporan Pengelompokan Data Terstruktur</h1>
    
    <div class="nav">
        <a href="index.php">Form Input</a>
        <a href="index.php?action=report&type=structured">Laporan Terstruktur</a>
        <a href="index.php?action=report">Laporan Horizontal</a>
    </div>
    
    <?php if (isset($_SESSION['structured_report']) && !empty($_SESSION['structured_report'])): ?>
        <?php foreach ($_SESSION['structured_report'] as $jurnal => $data): ?>
            <div class="month-section">
                <div class="month-header">
                    JURNAL: <?php echo htmlspecialchars($jurnal); ?>
                </div>
                
                <?php if (isset($data['setoran']) && !empty($data['setoran'])): ?>
                    <div class="subcategory-section setoran-section">
                        <div class="subcategory-header setoran-header">
                            UANG SETORAN
                        </div>
                        <table class="transaction-table">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>No Kwitansi</th>
                                    <th>Uraian</th>
                                    <th>Kas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $total_setoran = 0;
                                foreach ($data['setoran'] as $setoran): 
                                    $total_setoran += $setoran['jumlah'];
                                ?>
                                    <tr>
                                        <td><?php echo date('d-M', strtotime($setoran['tanggal'])); ?></td>
                                        <td><?php echo htmlspecialchars($setoran['no_kwitansi']); ?></td>
                                        <td><?php echo htmlspecialchars($setoran['uraian']); ?></td>
                                        <td style="text-align: right;"><?php echo number_format($setoran['jumlah'], 2); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr class="total-row">
                                    <td colspan="3">Total Kas Uang Setoran:</td>
                                    <td><?php echo number_format($total_setoran, 2); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                
                <?php foreach ($data['kelompok'] as $kode_kelompok => $kelompok_data): ?>
                    <div class="subcategory-section">
                        <div class="subcategory-header">
                            KELOMPOK: <?php echo $kode_kelompok; ?> - <?php echo htmlspecialchars($kelompok_data['nama_kelompok']); ?>
                        </div>
                        
                        <?php foreach ($kelompok_data['subkategori'] as $kode_sub => $sub_data): ?>
                            <div style="margin-left: 20px; margin-bottom: 15px;">
                                <div style="font-weight: bold; margin-bottom: 8px; color: #2c3e50;">
                                    Subkategori: <?php echo $kode_sub; ?> - <?php echo htmlspecialchars($sub_data['nama_subkategori']); ?>
                                </div>
                                
                                <table class="transaction-table">
                                    <thead>
                                        <tr>
                                            <th>Tanggal</th>
                                            <th>No Kwitansi</th>
                                            <th>Uraian</th>
                                            <th>Kas</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $total_sub = 0;
                                        foreach ($sub_data['transaksi'] as $trx): 
                                            $total_sub += $trx['jumlah'];
                                        ?>
                                            <tr>
                                                <td><?php echo date('d-M', strtotime($trx['tanggal'])); ?></td>
                                                <td><?php echo htmlspecialchars($trx['no_kwitansi']); ?></td>
                                                <td><?php echo htmlspecialchars($trx['uraian']); ?></td>
                                                <td style="text-align: right;"><?php echo number_format($trx['jumlah'], 2); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <tr class="total-row">
                                            <td colspan="3">Total Kas <?php echo $kode_sub; ?>:</td>
                                            <td><?php echo number_format($total_sub, 2); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Tidak ada data laporan terstruktur. Silakan input data terlebih dahulu.</p>
    <?php endif; ?>
</body>
</html>