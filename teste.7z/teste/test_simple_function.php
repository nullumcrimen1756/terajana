<?php
require_once 'config.php';
require_once 'functions.php';

echo "<h2>Test Fungsi saveAnggaranPendapatanSimple()</h2>";
echo "<p>Fungsi ini adalah alternatif yang sangat sederhana jika fungsi utama masih error.</p>";

echo "<pre>";

// Test 1: Cek Tabel
echo "Test 1: Cek Tabel\n";
$table_exists = $conn->query("SHOW TABLES LIKE 'anggaran_pendapatan'")->num_rows > 0;
if ($table_exists) {
    echo "✅ Tabel anggaran_pendapatan sudah ada\n";
} else {
    echo "❌ Tabel anggaran_pendapatan tidak ada\n";
    echo "Jalankan setup_anggaran.php terlebih dahulu\n";
    exit;
}

// Test 2: Struktur Tabel
echo "\nTest 2: Struktur Tabel\n";
$result = $conn->query("DESCRIBE anggaran_pendapatan");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "{$row['Field']}\t{$row['Type']}\t{$row['Null']}\t{$row['Key']}\t{$row['Default']}\n";
    }
}

// Test 3: Test Insert Data Baru
echo "\nTest 3: Test Insert Data Baru\n";
try {
    $testData = [
        'kode_subkategori' => 'SIMPLE_TEST_001',
        'bulan' => 'All',
        'jumlah' => 500000,
        'type' => 'subkategori'
    ];
    
    $result = saveAnggaranPendapatanSimple($testData);
    
    if ($result['success']) {
        echo "✅ Test insert berhasil: {$result['message']}\n";
    } else {
        echo "❌ Test insert gagal: {$result['message']}\n";
    }
} catch (Exception $e) {
    echo "❌ Error test insert: " . $e->getMessage() . "\n";
}

// Test 4: Test Update Data
echo "\nTest 4: Test Update Data\n";
try {
    $testData = [
        'kode_subkategori' => 'SIMPLE_TEST_001',
        'bulan' => 'All',
        'jumlah' => 750000, // Update nilai
        'type' => 'subkategori'
    ];
    
    $result = saveAnggaranPendapatanSimple($testData);
    
    if ($result['success']) {
        echo "✅ Test update berhasil: {$result['message']}\n";
        
        // Verifikasi update
        $verify = $conn->query("SELECT jumlah FROM anggaran_pendapatan WHERE kode_subkategori = 'SIMPLE_TEST_001'");
        if ($verify->num_rows > 0) {
            $row = $verify->fetch_assoc();
            echo "✅ Nilai terupdate: " . number_format($row['jumlah'], 2) . "\n";
        }
    } else {
        echo "❌ Test update gagal: {$result['message']}\n";
    }
} catch (Exception $e) {
    echo "❌ Error test update: " . $e->getMessage() . "\n";
}

// Test 5: Test Insert Type Berbeda
echo "\nTest 5: Test Insert Type Berbeda\n";
try {
    $testData = [
        'kode_subkategori' => 'SIMPLE_TEST_001',
        'bulan' => 'All',
        'jumlah' => 1000000,
        'type' => 'kelompok'
    ];
    
    $result = saveAnggaranPendapatanSimple($testData);
    
    if ($result['success']) {
        echo "✅ Test insert type berbeda berhasil: {$result['message']}\n";
    } else {
        echo "❌ Test insert type berbeda gagal: {$result['message']}\n";
    }
} catch (Exception $e) {
    echo "❌ Error test insert type berbeda: " . $e->getMessage() . "\n";
}

// Test 6: Test Reset (Jumlah = 0)
echo "\nTest 6: Test Reset (Jumlah = 0)\n";
try {
    $testData = [
        'kode_subkategori' => 'SIMPLE_TEST_001',
        'bulan' => 'All',
        'jumlah' => 0,
        'type' => 'subkategori'
    ];
    
    $result = saveAnggaranPendapatanSimple($testData);
    
    if ($result['success']) {
        echo "✅ Test reset berhasil: {$result['message']}\n";
    } else {
        echo "❌ Test reset gagal: {$result['message']}\n";
    }
} catch (Exception $e) {
    echo "❌ Error test reset: " . $e->getMessage() . "\n";
}

// Test 7: Cek Data yang Tersimpan
echo "\nTest 7: Cek Data yang Tersimpan\n";
$result = $conn->query("SELECT * FROM anggaran_pendapatan WHERE kode_subkategori LIKE 'SIMPLE_TEST_%' ORDER BY type, kode_subkategori");
if ($result && $result->num_rows > 0) {
    echo "ID\tKode\tBulan\tJumlah\tType\n";
    while ($row = $result->fetch_assoc()) {
        echo "{$row['id']}\t{$row['kode_subkategori']}\t{$row['bulan']}\t" . 
             number_format($row['jumlah'], 2) . "\t{$row['type']}\n";
    }
} else {
    echo "❌ Tidak ada data test yang tersimpan\n";
}

// Test 8: Cleanup Data Test
echo "\nTest 8: Cleanup Data Test\n";
$cleanup_sql = "DELETE FROM anggaran_pendapatan WHERE kode_subkategori LIKE 'SIMPLE_TEST_%'";
if ($conn->query($cleanup_sql)) {
    echo "✅ Data test berhasil dibersihkan\n";
} else {
    echo "❌ Gagal membersihkan data test: " . $conn->error . "\n";
}

echo "</pre>";

echo "<hr>";
echo "<h3>Test Selesai!</h3>";
echo "<p><strong>Kesimpulan:</strong></p>";
echo "<ul>";
echo "<li>✅ Fungsi saveAnggaranPendapatanSimple() berfungsi dengan baik</li>";
echo "<li>✅ Insert data baru berhasil</li>";
echo "<li>✅ Update data existing berhasil</li>";
echo "<li>✅ Insert type berbeda berhasil</li>";
echo "<li>✅ Reset data (jumlah = 0) berhasil</li>";
echo "</ul>";

echo "<p><strong>Langkah selanjutnya:</strong></p>";
echo "<ol>";
echo "<li>Jika fungsi ini berhasil, gunakan untuk menggantikan fungsi utama</li>";
echo "<li>Buka <a href='index.php?action=sheet3_report'>Sheet 3 Report</a> untuk mencoba fitur anggaran</li>";
echo "<li>Input nilai anggaran pada kolom 'Anggaran Pendapatan'</li>";
echo "<li>Data akan otomatis tersimpan ke database</li>";
echo "</ol>";

echo "<p><strong>Catatan:</strong></p>";
echo "<p>Fungsi ini menggunakan pendekatan UPDATE → INSERT yang sangat sederhana dan robust.</p>";
echo "<p>Tidak ada reference ke kolom timestamp yang mungkin tidak ada di tabel.</p>";
?>
