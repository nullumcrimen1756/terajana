<?php
// Tambahkan filter jurnal di bagian atas laporan
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';

// Daftar jurnal yang menggunakan "Uang dari Bank" bukan "Setoran"
$jurnal_uang_dari_bank = [2, 3, 4]; // ID jurnal: Penerimaan Jemaat, Penerimaan Jemaat Saldo Bank Mandiri, Penerimaan GSG
$label_setoran = in_array($selected_jurnal_filter, $jurnal_uang_dari_bank) ? "Uang dari Bank" : "Setoran";
?>

<div class="card mb-4">
    <div class="card-header">
        <h6 class="mb-0">Filter Laporan Sheet 1</h6>
    </div>
    <div class="card-body">
        <form method="get" action="index.php" class="row g-3 align-items-center">
            <input type="hidden" name="action" value="sheet1_report">
            <div class="col-md-3">
                <label for="jurnal_filter" class="form-label">Jurnal:</label>
                <select name="jurnal_filter" id="jurnal_filter" class="form-select" onchange="this.form.submit()">
                    <option value="">Semua Jurnal</option>
                    <?php foreach ($daftar_jurnal as $id => $nama): ?>
                        <option value="<?= $id ?>" <?= ($selected_jurnal_filter == $id) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($nama) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="tahun_filter" class="form-label">Tahun:</label>
                <select name="tahun_filter" id="tahun_filter" class="form-select" onchange="this.form.submit()">
                    <?php for ($year = date('Y'); $year >= 2020; $year--): ?>
                        <option value="<?= $year ?>" <?= ($selected_tahun_filter == $year) ? 'selected' : '' ?>>
                            <?= $year ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="search" class="form-label">Pencarian:</label>
                <div class="input-group">
                    <input type="text" 
                           name="search" 
                           id="search" 
                           class="form-control" 
                           value="<?= htmlspecialchars($search_keyword) ?>" 
                           placeholder="Cari nomor kwitansi atau uraian...">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label">&nbsp;</label><br>
                <a href="index.php?action=sheet1_report" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-clockwise me-1"></i>Reset
                </a>
            </div>
        </form>
    </div>
</div>

<?php
// Ambil data transaksi berdasarkan filter
$where_conditions = [];
$params = [];
$types = "";

if ($selected_jurnal_filter) {
    $where_conditions[] = "t.id_jurnal = ?";
    $params[] = $selected_jurnal_filter;
    $types .= "i";
}

if ($selected_tahun_filter) {
    $where_conditions[] = "YEAR(t.tanggal) = ?";
    $params[] = $selected_tahun_filter;
    $types .= "i";
}

if ($search_keyword) {
    $where_conditions[] = "(t.no_kwitansi LIKE ? OR t.uraian LIKE ?)";
    $params[] = "%$search_keyword%";
    $params[] = "%$search_keyword%";
    $types .= "ss";
}

$where_clause = "";
if (!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

$sql = "SELECT 
            t.*,
            j.nama_jurnal,
            k.kode_kategori,
            k.nama_kategori,
            s.kode_subkategori,
            s.nama_subkategori
        FROM transaksi t
        JOIN jurnal j ON t.id_jurnal = j.id_jurnal
        LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
        LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
        $where_clause
        ORDER BY t.tanggal DESC, t.created_at DESC";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$transactions = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
}

// Ambil semua kode kategori unik untuk header tabel
$unique_kategori = [];
foreach ($transactions as $trans) {
    if (!empty($trans['kode_kategori'])) {
        $kode_kelompok = substr($trans['kode_kategori'], 0, 3);
        if (!in_array($kode_kelompok, $unique_kategori)) {
            $unique_kategori[] = $kode_kelompok;
        }
    }
}
sort($unique_kategori);
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <i class="bi bi-table me-2"></i>Laporan Sheet 1 - Data Transaksi
            <?php if ($selected_jurnal_filter): ?>
                <span class="badge bg-primary ms-2"><?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></span>
            <?php endif; ?>
            <?php if ($selected_tahun_filter): ?>
                <span class="badge bg-secondary ms-1">Tahun: <?= $selected_tahun_filter ?></span>
            <?php endif; ?>
            <?php if ($search_keyword): ?>
                <span class="badge bg-info ms-1">Pencarian: "<?= htmlspecialchars($search_keyword) ?>"</span>
            <?php endif; ?>
        </h5>
    </div>
    <div class="card-body">
        <?php if (!empty($transactions)): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover table-sm" id="sheet1Table">
                    <thead class="table-dark">
                        <tr>
                            <th class="text-center" style="width: 100px;">Tanggal</th>
                            <th class="text-center" style="width: 120px;">KW</th>
                            <th class="text-center" style="min-width: 200px;">Uraian</th>
                            <th class="text-center" style="width: 120px;">Kas</th>
                            <?php foreach ($unique_kategori as $kode_kelompok): ?>
                                <th class="text-center" style="width: 100px;">Kode <?= $kode_kelompok ?></th>
                                <th class="text-center" style="width: 120px;">Nominal <?= $kode_kelompok ?></th>
                            <?php endforeach; ?>
                            <th class="text-center" style="width: 120px;"><?= $label_setoran ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_kas = 0;
                        $total_setoran = 0;
                        
                        // Inisialisasi total per kategori
                        $totals_per_kategori = [];
                        foreach ($unique_kategori as $kode_kelompok) {
                            $totals_per_kategori[$kode_kelompok] = 0;
                        }
                        
                        foreach ($transactions as $trans): 
                            $kas = $trans['jumlah'] + ($trans['setoran'] ?? 0);
                            $setoran = $trans['setoran'] ?? 0;
                            
                            // Update total
                            $total_kas += $kas;
                            $total_setoran += $setoran;
                        ?>
                            <tr>
                                <td class="text-center"><?= date('d-m-Y', strtotime($trans['tanggal'])) ?></td>
                                <td class="text-center"><?= htmlspecialchars($trans['no_kwitansi']) ?></td>
                                <td>
                                    <div class="fw-bold"><?= htmlspecialchars($trans['uraian']) ?></div>
                                    <small class="text-muted">
                                        <?= htmlspecialchars($trans['nama_jurnal']) ?> - 
                                        <?= htmlspecialchars($trans['nama_kategori'] ?? 'N/A') ?>
                                    </small>
                                </td>
                                <td class="text-end fw-bold">Rp <?= number_format($kas, 0, ',', '.') ?></td>
                                <?php 
                                // Inisialisasi semua kolom kategori dengan nilai kosong
                                $kategori_values = [];
                                foreach ($unique_kategori as $kode_kelompok) {
                                    $kategori_values[$kode_kelompok] = [
                                        'kode' => '',
                                        'nominal' => ''
                                    ];
                                }
                                
                                // Isi nilai untuk kategori yang sesuai
                                if (!empty($trans['kode_kategori'])) {
                                    $kode_kelompok = substr($trans['kode_kategori'], 0, 3);
                                    if (in_array($kode_kelompok, $unique_kategori)) {
                                        $kategori_values[$kode_kelompok]['kode'] = $trans['kode_subkategori'] ?? '';
                                        $kategori_values[$kode_kelompok]['nominal'] = $trans['jumlah'];
                                        $totals_per_kategori[$kode_kelompok] += $trans['jumlah'];
                                    }
                                }
                                
                                // Tampilkan kolom untuk setiap kategori
                                foreach ($unique_kategori as $kode_kelompok): 
                                ?>
                                    <td class="text-center"><?= htmlspecialchars($kategori_values[$kode_kelompok]['kode']) ?></td>
                                    <td class="text-end"><?= $kategori_values[$kode_kelompok]['nominal'] ? 'Rp ' . number_format($kategori_values[$kode_kelompok]['nominal'], 0, ',', '.') : '' ?></td>
                                <?php endforeach; ?>
                                <td class="text-end"><?= $setoran ? 'Rp ' . number_format($setoran, 0, ',', '.') : '' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="table-info">
                        <tr class="fw-bold">
                            <td colspan="3" class="text-center">TOTAL</td>
                            <td class="text-end">Rp <?= number_format($total_kas, 0, ',', '.') ?></td>
                            <?php foreach ($unique_kategori as $kode_kelompok): ?>
                                <td></td>
                                <td class="text-end">Rp <?= number_format($totals_per_kategori[$kode_kelompok], 0, ',', '.') ?></td>
                            <?php endforeach; ?>
                            <td class="text-end">Rp <?= number_format($total_setoran, 0, ',', '.') ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <!-- Ringkasan Statistik -->
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Ringkasan Per Kategori</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <?php 
                                $colors = ['primary', 'success', 'warning', 'info', 'danger', 'secondary'];
                                $color_index = 0;
                                
                                foreach ($unique_kategori as $kode_kelompok): 
                                    $color = $colors[$color_index % count($colors)];
                                    $color_index++;
                                ?>
                                    <div class="col-6 mb-2">
                                        <div class="text-center p-2 bg-light rounded">
                                            <div class="fw-bold text-<?= $color ?>">Kategori <?= $kode_kelompok ?></div>
                                            <div>Rp <?= number_format($totals_per_kategori[$kode_kelompok], 0, ',', '.') ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Ringkasan Umum</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="text-center p-2 bg-light rounded">
                                        <div class="fw-bold text-dark">Total Kas</div>
                                        <div>Rp <?= number_format($total_kas, 0, ',', '.') ?></div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="text-center p-2 bg-light rounded">
                                        <div class="fw-bold text-secondary">Total <?= $label_setoran ?></div>
                                        <div>Rp <?= number_format($total_setoran, 0, ',', '.') ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-12">
                                    <div class="text-center p-2 bg-light rounded">
                                        <div class="fw-bold text-primary">Total Transaksi</div>
                                        <div><?= count($transactions) ?> transaksi</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        <?php else: ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                <?php if ($search_keyword): ?>
                    Tidak ada data yang cocok dengan pencarian "<?= htmlspecialchars($search_keyword) ?>".
                <?php elseif ($selected_jurnal_filter): ?>
                    Tidak ada data transaksi untuk jurnal yang dipilih.
                <?php else: ?>
                    Tidak ada data transaksi untuk filter yang dipilih.
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
#sheet1Table {
    font-size: 0.875rem;
}

#sheet1Table th {
    background-color: #2c3e50;
    color: white;
    font-size: 0.8rem;
    vertical-align: middle;
}

#sheet1Table td {
    vertical-align: middle;
}

#sheet1Table tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.05);
}

.text-end {
    text-align: right !important;
}

.text-center {
    text-align: center !important;
}

.bg-light {
    background-color: #f8f9fa !important;
}

/* Responsive table */
@media (max-width: 768px) {
    #sheet1Table {
        font-size: 0.75rem;
    }
    
    #sheet1Table th,
    #sheet1Table td {
        padding: 0.25rem;
    }
}
</style>
